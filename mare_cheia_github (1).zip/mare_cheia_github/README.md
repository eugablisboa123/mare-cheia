# Maré Cheia — Blog de frutos do mar

Site em HTML e CSS sobre polvo, lagosta e camarão, com dicas de compra, preparo e receitas.

## Estrutura

- `index.html` — página inicial com imagens clicáveis para cada ingrediente.
- `polvo.html` — guia e receitas de polvo.
- `lagosta.html` — guia e receitas de lagosta.
- `camarao.html` — guia e receitas de camarão.
- `contatos.html` — página de contato.
- `css/estilo.css` — estilos responsivos do site.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos e a pasta `css`.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)` e salve.
6. Aguarde o GitHub Pages publicar o site.

As imagens estão hospedadas no Unsplash e precisam de conexão com a internet para carregar.

## Observação sobre o formulário

A página de contato usa `mailto:` como exemplo. Para receber mensagens de verdade sem abrir o aplicativo de e-mail da pessoa, conecte um serviço de formulários ou configure um backend.
